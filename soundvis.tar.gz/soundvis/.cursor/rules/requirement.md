React web app that displays dynamic visualization according to sound from microphone in realtime.

The visualization should be futuristic and abstract. Like moving clouds with energy disturbance.